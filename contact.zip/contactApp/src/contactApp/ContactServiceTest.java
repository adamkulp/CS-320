package contactApp;

import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	private ContactService cs;
	
	@BeforeEach
	public void setup () {
		cs = new ContactService();
	}
	@Test
	public void testAddValidContact() {

		
			Map <String, Contact> c = cs.addContact(new Contact("0000000002", "Adam", "Kulp","8503710033","adamkulp@gmail.com"));

		
		Assertions.assertNotNull(c.get("0000000002"));
	}	
	@Test
	public void testDeleteValidContact() {

		cs.addContact(new Contact("0000000002", "Adam", "Kulp","8503710033","adamkulp@gmail.com"));
			Map <String, Contact> c = cs.deleteContact("0000000002");

		
		Assertions.assertNull(c.get("0000000002"));
	}	
	@Test
	public void testUpdateValidContact() {

		cs.addContact(new Contact("0000000002", "Adam", "Kulp","8503710033","adamkulp@gmail.com"));
			Map <String, Contact> c = cs.updateContact("0000000002", "John", "Smith","1234567890","johnsmith@aol.com");

		
		Assertions.assertEquals(c.get("0000000002").getFirstName(),"John");
		Assertions.assertEquals(c.get("0000000002").getLastName(),"Smith");
		Assertions.assertEquals(c.get("0000000002").getPhone(),"1234567890");
		Assertions.assertEquals(c.get("0000000002").getAddress(),"johnsmith@aol.com");
	}	
}
