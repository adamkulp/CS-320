package contactApp;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class ContactTest {
	@Test
	public void testInvalidID() {

		boolean isValid = true;
		try {
			new Contact("0000000002x", "Adam", "Kulp","8503710033","adamkulp@gmail.com");

		} catch (Exception e) {
			isValid = false;
		}
		Assertions.assertFalse(isValid);
	}
	@Test
	public void testInvalidFirstName() {

		boolean isValid = true;
		try {
			new Contact("0000000002", "Adamzzzzzzzz", "Kulp","8503710033","adamkulp@gmail.com");

		} catch (Exception e) {
			isValid = false;
		}
		Assertions.assertFalse(isValid);
	}
	@Test
	public void testInvalidLastName() {

		boolean isValid = true;
		try {
			new Contact("0000000002", "Adam", "Kulpzzzzzzz","8503710033","adamkulp@gmail.com");

		} catch (Exception e) {
			isValid = false;
		}
		Assertions.assertFalse(isValid);
	}
	@Test
	public void testInvalidPhoneNumber() {

		boolean isValid = true;
		try {
			new Contact("0000000002", "Adam", "Kulp","850-371-0033","adamkulp@gmail.com");

		} catch (Exception e) {
			isValid = false;
		}
		Assertions.assertFalse(isValid);
	}
	@Test
	public void testInvalidEmail() {

		boolean isValid = true;
		try {
			new Contact("0000000002", "Adam", "Kulp","8503710033","adamkulp@gmail.com adamkulp@gmail.com adamkulp@gmail.com adamkulp@gmail.com");

		} catch (Exception e) {
			isValid = false;
		}
		Assertions.assertFalse(isValid);
	}
	@Test
	public void testValidContact() {

		boolean isValid = true;
		try {
			new Contact("0000000002", "Adam", "Kulp","8503710033","adamkulp@gmail.com");

		} catch (Exception e) {
			isValid = false;
		}
		Assertions.assertTrue(isValid);
	}	
}
