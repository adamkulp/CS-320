package contactApp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class ContactService {
	
	   
	   private static Map<String, Contact> contacts = new HashMap<>();

	
	   public Map<String, Contact> addContact(Contact contact) {
	      
	       contacts.put(contact.getContactID(), contact);
	       return contacts;
	   }
	  
	  

	   public Map<String, Contact> deleteContact(String contactID) {

	       contacts.remove(contactID);

	       return contacts;

	   }
	  
	 
	   public Map<String, Contact> updateContact(String contactID, String firstName, String lastName, String number,
	           String address) {

	       Contact c = contacts.get(contactID);
	           if (c != null) {
	               c.setFirstName(firstName);
	               c.setLastName(lastName);
	               c.setPhone(number);
	               c.setAddress(address);
	           }

	       

	       return contacts;

	   
	}
}
